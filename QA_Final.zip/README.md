devchallenge.it--qa--final

Final round QA task for DEV Challenge 12

# Jira link
Open this link [link](https://devchgallengefinal.atlassian.net/)

# Jira acess:
>Email - checkflatbill@gmail.com
>Password - xc12XC!@

# Project link
Project can be found [here](https://devchgallengefinal.atlassian.net/browse/TRIP)

# Artifacts:
Check list,
Test Plan,
Test Report